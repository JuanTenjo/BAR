<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="<?php echo base_url(); ?>Style/StylesAdmin/style.css" type="text/css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css2?family=Coming+Soon&display=swap" rel="stylesheet">
	<title>Administracion</title>
</head>

<body>
	<!-- ADMINISTRACION -->
	<?php $Administrador = $this->session->userdata('USUARIO'); ?>
	<div class="container-fluid">
		<div class="row">
			<div class="col-12" style="float:right;">
				<ul class="nav nav-tabs menu">
					<li class="nav-item">
						<a class="nav-link " aria-current="page" href="<?php echo base_url() ?>index.php/administrador">Inicio</a>
					</li>
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="<?php echo base_url() ?>index.php/administrador/Productos">Productos</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#">Link</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#">Link</a>
					</li>
					<li class="nav-item">
						<a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
					</li>
				</ul>
			</div>
		</div>
	</div>

	<br>

	<div class="container-fluid">
		<div class="row">
			<h5>Cree un producto</h5>
			<div class="table-responsive">
				<form action="<?php echo base_url() ?>index.php/administrador/registrar_productos" method="post">
					<table class="table table-hover">
						<thead class="table-dark head">
							<tr>
								<th scope="col">Categoria</th>
								<th scope="col">Nombre Producto</th>
								<th scope="col">Ingredientes</th>
								<th scope="col">Cantidad</th>
								<th scope="col">Precio</th>
								<th scope="col">Agregar</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th scope="row">
									<select name="IDCategoria" class="form-control" id="exampleFormControlSelect1">
									<option value="false" disabled selected>Categoria</option>
									<?php  foreach ($categorias->result() as $row) { ?>
									<option value="<?php/echo ($row->ID_Categoria); ?>"><?php echo ($row->NombreCate); ?></option>
									<?php } ?> 
									</select>
								</th>
								<td>
									<div class="form-group">
										<input type="text" class="form-control" placeholder="Nombre del producto">
									</div>
								</td>
								<td>
									<div class="form-group">
										<input type="number" class="form-control" placeholder="Ingredientes">
									</div>
								</td>
								<td>
									<div class="form-group">
										<input type="number" class="form-control" placeholder="Cantidad">
									</div>
								</td>
								<td>
									<div class="form-group">
										<input type="number" class="form-control" placeholder="Precio">
									</div>
								</td>
								<td>
									<div class="form-group" >
									<center>
										<button type="submit" class="btn btn-success center-block">Agregar</button>
									</center>
									</div>
								</td>
							</tr>
						</tbody>
					</table>
				</form>
			</div>
		</div>




		<div class="row">
		<h5>Lista de productos</h5>
		<div class="table-responsive">
				<form action="<?php echo base_url() ?>index.php/administrador/registrar_productos" method="post">
					<table class="table">
						<thead class="head">
							<tr>
						
								<th scope="col">Categoria</th>
								<th scope="col">Nombre Producto</th>
								<th scope="col">Ingredientes</th>
								<th scope="col">Cantidad</th>
								<th scope="col">Precio</th>
								<th scope="col">Modificar</th>
								<th scope="col">Eliminar</th>
							</tr>
						</thead>
						<tbody>
						<?php foreach ($productos->result() as $row) { ?>
							<form action="#" method="post" data-ajax="false">
							<tr>
								<th scope="row">
									<div class="form-group">
										<input type="text" value="<?php echo ($row->ID_Categoria) ?>" class="form-control" placeholder="Categoria">
									</div>
								</th>
								<td>
									<div class="form-group">
										<input type="text" value="<?php echo ($row->Ingredientes) ?>" class="form-control" placeholder="Nombre del producto">
									</div>
								</td>
								<td>
									<div class="form-group">
										<input type="text" value="<?php echo ($row->Ingredientes) ?>" class="form-control" placeholder="Nombre del producto">
									</div>
								</td>
								<td>
									<div class="form-group">
										<input type="number" value="<?php echo ($row->Cantidad) ?>" class="form-control" placeholder="Ingredientes">
									</div>
								</td>
								<td>
									<div class="form-group">
										<input type="number" value="<?php echo ($row->Precio) ?>" class="form-control" placeholder="Cantidad">
									</div>
								</td>
								<td>
									<div class="form-group">
										<center>
										<button type="submit" class="btn btn-warning center-block">Modificar</button>
										</center>
									</div>
								</td>
								<td>
									<div class="form-group" >
										<center>
										<button type="submit" class="btn btn-danger center-block">Eliminar</button>
										</center>
									</div>
								</td>
							</tr>
							</form>
						<?php } ?>
						</tbody>
					</table>
				</form>
			</div>						
		</div>
	</div>


	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>
