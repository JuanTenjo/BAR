<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Administrador extends CI_Controller {

    function __construct(){
        parent::__construct();
        $this->load->model('model_registro');
        $this->load->model('model_mostrar_productos');
		$this->load->model('Model_Admin');
    }

	public function index()
	{
		if ($this->session->userdata('is_logged_in')) {
			$this->load->view('VistasAdmin/View_Inicio');
		}
    }

	public function Productos()
	{
		if ($this->session->userdata('is_logged_in')) {
			$data = array(
				'productos' => $this->Model_Admin->MostrarProductos(),
				'categorias' => $this->Model_Admin->MostrarCategorias()
			);	
			$this->load->view('VistasAdmin/View_Productos',$data);
		}
    }

    public function registrar_productos(){
        $tipo = $this->input->post('tipo');
        $nombre = $this->input->post('nombre');
        $precio = $this->input->post('precio');
        $re = $this->model_registro->registrar_productos($tipo,$nombre,$precio);
    }
    public function registrar_categoria(){
        $nombre = $this->input->post('nombreCategoria');
        $re = $this->model_registro->registrar_categoria($nombre);
    } 
    public function eliminarcategoria(){
        $id = $this->input->post('id');
        $re = $this->model_registro->eliminarcategoria($id);
    }
    public function eliminarproducto(){
        $id = $this->input->post('id');
        $re = $this->model_registro->eliminarproducto($id);
    }
    public function salir(){
        $this->load->view('inicio');
    }
    public function agregarzona(){
       $nombre = $this->input->post('nombre');
       $mesas = $this->input->post('mesas');
       $id_zona = $this->input->post('id_zona');
       $re = $this->model_registro->agregarzona($nombre,$mesas,$id_zona);
    }
    public function editarzonas(){
        $idzonas = $this->input->post('id');
        $mesas = $this->input->post('mesas');
        $re = $this->model_registro->editarzonas($idzonas,$mesas);
    }
    public function eliminarzona(){
        $idzonas = $this->input->post('id');
        $re = $this->model_registro->eliminarzona($idzonas);
    }
}
